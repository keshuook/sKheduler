from webbrowser import open_new
open_new("http://localhost:9000")